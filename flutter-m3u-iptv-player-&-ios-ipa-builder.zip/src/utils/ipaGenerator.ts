import JSZip from 'jszip';
import { AppConfig, IpaFileNode } from '../types/ipa';

/**
 * Generate Info.plist XML content based on user configuration
 */
export function generateInfoPlist(config: AppConfig): string {
  const deviceFamilies = config.targetDevice === 'iPhone' 
    ? '<integer>1</integer>' 
    : config.targetDevice === 'iPad' 
      ? '<integer>2</integer>' 
      : '<integer>1</integer>\n    <integer>2</integer>';

  let permissionsXml = '';
  if (config.permissions.camera) {
    permissionsXml += `\n    <key>NSCameraUsageDescription</key>\n    <string>This app requires access to your camera to scan documents and capture media for ${config.appName}.</string>`;
  }
  if (config.permissions.location) {
    permissionsXml += `\n    <key>NSLocationWhenInUseUsageDescription</key>\n    <string>Your location is used to display localized metrics and track workout routes.</string>`;
  }
  if (config.permissions.photoLibrary) {
    permissionsXml += `\n    <key>NSPhotoLibraryUsageDescription</key>\n    <string>Access to your photo library is needed to attach images to your notes.</string>`;
  }
  if (config.permissions.faceId) {
    permissionsXml += `\n    <key>NSFaceIDUsageDescription</key>\n    <string>Authenticate securely with Face ID to unlock your private logs and credentials.</string>`;
  }
  if (config.permissions.healthKit) {
    permissionsXml += `\n    <key>NSHealthShareUsageDescription</key>\n    <string>Read your daily steps, heart rate, and activity to synchronize health goals.</string>\n    <key>NSHealthUpdateUsageDescription</key>\n    <string>Save workout sessions and activity updates to Apple Health.</string>`;
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleDevelopmentRegion</key>
    <string>en</string>
    <key>CFBundleDisplayName</key>
    <string>${config.appName}</string>
    <key>CFBundleExecutable</key>
    <string>${config.appName.replace(/[^a-zA-Z0-9]/g, '')}</string>
    <key>CFBundleIdentifier</key>
    <string>${config.bundleId}</string>
    <key>CFBundleInfoDictionaryVersion</key>
    <string>6.0</string>
    <key>CFBundleName</key>
    <string>${config.appName}</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>${config.version}</string>
    <key>CFBundleVersion</key>
    <string>${config.buildNumber}</string>
    <key>LSRequiresIPhoneOS</key>
    <true/>
    <key>MinimumOSVersion</key>
    <string>${config.minIosVersion}</string>
    <key>UIDeviceFamily</key>
    <array>
        ${deviceFamilies}
    </array>
    <key>UILaunchStoryboardName</key>
    <string>LaunchScreen</string>
    <key>UIRequiredDeviceCapabilities</key>
    <array>
        <string>arm64</string>
    </array>
    <key>UISupportedInterfaceOrientations</key>
    <array>
        <string>UIInterfaceOrientationPortrait</string>
        <string>UIInterfaceOrientationPortraitUpsideDown</string>
        <string>UIInterfaceOrientationLandscapeLeft</string>
        <string>UIInterfaceOrientationLandscapeRight</string>
    </array>
    <key>UIRequiresFullScreen</key>
    <true/>
    <key>ITSAppUsesNonExemptEncryption</key>
    <false/>${permissionsXml}
</dict>
</plist>`;
}

/**
 * Generate iTunesMetadata.plist for App Store / Sideloading metadata
 */
export function generateItunesMetadata(config: AppConfig): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>bundleDisplayName</key>
    <string>${config.appName}</string>
    <key>bundleShortVersionString</key>
    <string>${config.version}</string>
    <key>bundleVersion</key>
    <string>${config.buildNumber}</string>
    <key>genre</key>
    <string>${config.category}</string>
    <key>genreId</key>
    <integer>6007</integer>
    <key>itemId</key>
    <integer>1648291048</integer>
    <key>itemName</key>
    <string>${config.appName}</string>
    <key>softwareVersionBundleId</key>
    <string>${config.bundleId}</string>
    <key>softwareVersionExternalIdentifier</key>
    <integer>85023910</integer>
    <key>copyright</key>
    <string>© 2026 Prototype Studios Inc.</string>
</dict>
</plist>`;
}

/**
 * Generate embedded.mobileprovision mock (development signing descriptor)
 */
export function generateMobileProvision(config: AppConfig): string {
  const expiryDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString();
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>AppIDName</key>
    <string>${config.appName} Development Profile</string>
    <key>ApplicationIdentifierPrefix</key>
    <array>
        <string>9X87ABCDEF</string>
    </array>
    <key>CreationDate</key>
    <date>${new Date().toISOString()}</date>
    <key>ExpirationDate</key>
    <date>${expiryDate}</date>
    <key>Name</key>
    <string>iOS Team Provisioning Profile: ${config.bundleId}</string>
    <key>TeamIdentifier</key>
    <array>
        <string>9X87ABCDEF</string>
    </array>
    <key>TeamName</key>
    <string>Prototype Development Team</string>
    <key>TimeToLive</key>
    <integer>365</integer>
    <key>UUID</key>
    <string>c38f94d0-4097-4c16-8618-492982d6ec22</string>
    <key>Entitlements</key>
    <dict>
        <key>application-identifier</key>
        <string>9X87ABCDEF.${config.bundleId}</string>
        <key>keychain-access-groups</key>
        <array>
            <string>9X87ABCDEF.*</string>
        </array>
        <key>get-task-allow</key>
        <true/>
    </dict>
</dict>
</plist>`;
}

/**
 * Generate CodeResources XML (simulated Apple code signature directory)
 */
export function generateCodeResources(config: AppConfig): string {
  const binaryName = config.appName.replace(/[^a-zA-Z0-9]/g, '');
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>files</key>
    <dict>
        <key>Info.plist</key>
        <data>bW9jay1zaGEyNTYtaGFzaC1pbmZvLXBsaXN0</data>
        <key>${binaryName}</key>
        <data>bW9jay1zaGEyNTYtaGFzaC1iaW5hcnk=</data>
        <key>AppIcon60x60@2x.png</key>
        <data>bW9jay1zaGEyNTYtaGFzaC1pY29u</data>
        <key>www/index.html</key>
        <data>bW9jay1zaGEyNTYtaGFzaC1odG1s</data>
    </dict>
    <key>rules</key>
    <dict>
        <key>^.*</key>
        <true/>
        <key>^Info\\.plist$</key>
        <dict>
            <key>omit</key>
            <true/>
            <key>weight</key>
            <real>10</real>
        </dict>
    </dict>
</dict>
</plist>`;
}

/**
 * Generate Mach-O 64-bit binary header stub (ARM64 executable)
 * Magic number 0xFEEDFACF identifies a 64-bit Mach-O binary.
 */
export function generateMachOStub(config: AppConfig): Uint8Array {
  const binaryName = config.appName.replace(/[^a-zA-Z0-9]/g, '');
  const buffer = new Uint8Array(2048);
  
  // Mach-O 64-bit magic (MH_MAGIC_64 = 0xfeedfacf)
  buffer[0] = 0xcf;
  buffer[1] = 0xfa;
  buffer[2] = 0xed;
  buffer[3] = 0xfe;

  // CPU type: ARM64 (CPU_TYPE_ARM64 = 0x0100000c)
  buffer[4] = 0x0c;
  buffer[5] = 0x00;
  buffer[6] = 0x00;
  buffer[7] = 0x01;

  // CPU subtype: ARM64_ALL (0x00000000)
  buffer[8] = 0x00;
  buffer[9] = 0x00;
  buffer[10] = 0x00;
  buffer[11] = 0x00;

  // Filetype: MH_EXECUTE (0x00000002)
  buffer[12] = 0x02;
  buffer[13] = 0x00;
  buffer[14] = 0x00;
  buffer[15] = 0x00;

  // Number of load commands: 2
  buffer[16] = 0x02;
  buffer[17] = 0x00;
  buffer[18] = 0x00;
  buffer[19] = 0x00;

  // Size of load commands
  buffer[20] = 0x80;
  buffer[21] = 0x00;
  buffer[22] = 0x00;
  buffer[23] = 0x00;

  // Flags: MH_NOUNDEFS | MH_DYLDLINK | MH_PIE (0x00200085)
  buffer[24] = 0x85;
  buffer[25] = 0x00;
  buffer[26] = 0x20;
  buffer[27] = 0x00;

  // Text payload info
  const text = `// Apple Mach-O 64-bit ARM64 Executable Stub\n// Target: ${binaryName}\n// Bundle: ${config.bundleId}\n// Generated by iOS IPA Prototype Studio\n`;
  const encoder = new TextEncoder();
  const textBytes = encoder.encode(text);
  buffer.set(textBytes, 128);

  return buffer;
}

/**
 * Generate Standalone HTML Prototype for the embedded www/ directory
 */
export function generateStandaloneWebBundle(config: AppConfig): { html: string; css: string; js: string } {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>${config.appName}</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="ios-status-bar">
    <span id="clock">9:41</span>
    <div class="notch-indicator"></div>
    <div class="ios-icons">
      <span>5G</span>
      <div class="battery-icon"><div class="battery-fill"></div></div>
    </div>
  </div>

  <main class="app-container">
    <header class="app-header">
      <div class="date-label">TODAY</div>
      <h1>${config.appName}</h1>
      <p class="subtitle">iOS Prototype Application</p>
    </header>

    <div class="card stat-card">
      <div class="stat-badge">ACTIVE BUILD</div>
      <div class="stat-number">v${config.version}</div>
      <div class="stat-desc">Bundle: ${config.bundleId}</div>
    </div>

    <section class="section">
      <h2>Prototype Checklist</h2>
      <div id="todo-list" class="todo-list">
        <!-- populated via js -->
      </div>
    </section>

    <div class="action-wrap">
      <button id="add-btn" class="ios-btn">Add New Item</button>
    </div>
  </main>

  <nav class="tab-bar">
    <div class="tab-item active">Home</div>
    <div class="tab-item">Tasks</div>
    <div class="tab-item">Analytics</div>
    <div class="tab-item">Settings</div>
  </nav>

  <script src="app.js"></script>
</body>
</html>`;

  const css = `* { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", sans-serif; }
body { background: #000000; color: #ffffff; -webkit-font-smoothing: antialiased; padding-bottom: 90px; }
.ios-status-bar { display: flex; justify-content: space-between; align-items: center; padding: 12px 24px; font-size: 14px; font-weight: 600; }
.battery-icon { width: 22px; height: 11px; border: 1.5px solid #ffffff; border-radius: 3px; padding: 1px; display: inline-block; position: relative; margin-left: 6px; }
.battery-fill { width: 80%; height: 100%; background: #34c759; border-radius: 1px; }
.app-container { padding: 16px 20px; }
.app-header { margin-bottom: 24px; }
.date-label { font-size: 13px; font-weight: 700; color: #8e8e93; letter-spacing: 0.5px; }
h1 { font-size: 34px; font-weight: 700; letter-spacing: -0.5px; margin-top: 4px; }
.subtitle { font-size: 15px; color: #a1a1a6; margin-top: 2px; }
.card { background: #1c1c1e; border-radius: 16px; padding: 20px; margin-bottom: 24px; border: 1px solid rgba(255,255,255,0.08); }
.stat-badge { font-size: 11px; font-weight: 700; color: #0a84ff; letter-spacing: 1px; }
.stat-number { font-size: 32px; font-weight: 700; margin: 6px 0; }
.stat-desc { font-size: 13px; color: #8e8e93; word-break: break-all; }
h2 { font-size: 20px; font-weight: 600; margin-bottom: 12px; }
.todo-list { display: flex; flex-direction: column; gap: 8px; }
.todo-item { display: flex; align-items: center; gap: 12px; background: #1c1c1e; padding: 14px 16px; border-radius: 12px; }
.todo-checkbox { width: 20px; height: 20px; border-radius: 50%; border: 2px solid #0a84ff; cursor: pointer; }
.todo-checkbox.checked { background: #0a84ff; }
.ios-btn { width: 100%; padding: 16px; background: #0a84ff; color: #ffffff; border: none; border-radius: 14px; font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 16px; }
.tab-bar { position: fixed; bottom: 0; left: 0; right: 0; height: 75px; background: rgba(28,28,30,0.92); backdrop-filter: blur(20px); display: flex; justify-content: space-around; align-items: center; border-top: 1px solid rgba(255,255,255,0.1); padding-bottom: 12px; }
.tab-item { font-size: 11px; color: #8e8e93; text-align: center; }
.tab-item.active { color: #0a84ff; font-weight: 600; }`;

  const js = `(function() {
  const todos = [
    { title: "Review iOS entitlements & Info.plist", done: true },
    { title: "Verify Mach-O arm64 bundle signature", done: true },
    { title: "Test Dynamic Island and Haptics", done: false },
    { title: "Export to Sideloadly or TestFlight", done: false }
  ];

  const listEl = document.getElementById("todo-list");
  const addBtn = document.getElementById("add-btn");

  function render() {
    listEl.innerHTML = "";
    todos.forEach((todo, idx) => {
      const item = document.createElement("div");
      item.className = "todo-item";
      item.innerHTML = \`
        <div class="todo-checkbox \${todo.done ? 'checked' : ''}" data-idx="\${idx}"></div>
        <span style="\${todo.done ? 'text-decoration: line-through; opacity: 0.6;' : ''}">\${todo.title}</span>
      \`;
      item.addEventListener("click", () => {
        todos[idx].done = !todos[idx].done;
        render();
      });
      listEl.appendChild(item);
    });
  }

  addBtn.addEventListener("click", () => {
    const text = prompt("Enter new prototype task:");
    if (text) {
      todos.push({ title: text, done: false });
      render();
    }
  });

  render();
})();`;

  return { html, css, js };
}

/**
 * Creates a dynamic Canvas app icon rendered to PNG blob
 */
export async function generateAppIconBlob(config: AppConfig, size: number = 512): Promise<Blob> {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Smooth background gradient (Apple squircle aesthetic)
  const grad = ctx.createLinearGradient(0, 0, size, size);
  grad.addColorStop(0, config.themeColor || '#0A84FF');
  grad.addColorStop(1, '#5E5CE6');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  // Subtle concentric highlight
  ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
  ctx.beginPath();
  ctx.arc(size / 2, size / 2, size * 0.38, 0, Math.PI * 2);
  ctx.fill();

  // Draw modern App Glyph
  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `bold ${Math.floor(size * 0.42)}px -apple-system, BlinkMacSystemFont, sans-serif`;
  
  const initial = (config.appName.charAt(0) || 'A').toUpperCase();
  ctx.fillText(initial, size / 2, size / 2 + (size * 0.03));

  return new Promise((resolve) => {
    canvas.toBlob((blob) => resolve(blob || new Blob([])), 'image/png');
  });
}

/**
 * Builds the complete genuine .ipa file (ZIP format) with Apple-compliant file layout.
 */
export async function buildIpaArchive(config: AppConfig): Promise<{ blob: Blob; fileName: string }> {
  const zip = new JSZip();
  const binaryName = config.appName.replace(/[^a-zA-Z0-9]/g, '') || 'App';
  const appFolderName = `${binaryName}.app`;

  // Payload root directory
  const payload = zip.folder('Payload');
  if (!payload) throw new Error('Failed to create Payload directory');

  const appFolder = payload.folder(appFolderName);
  if (!appFolder) throw new Error('Failed to create app bundle directory');

  // 1. Info.plist
  const infoPlist = generateInfoPlist(config);
  appFolder.file('Info.plist', infoPlist);

  // 2. Mach-O ARM64 binary
  const binaryStub = generateMachOStub(config);
  appFolder.file(binaryName, binaryStub);

  // 3. embedded.mobileprovision
  const mobileProvision = generateMobileProvision(config);
  appFolder.file('embedded.mobileprovision', mobileProvision);

  // 4. _CodeSignature/CodeResources
  const codeSignature = appFolder.folder('_CodeSignature');
  if (codeSignature) {
    codeSignature.file('CodeResources', generateCodeResources(config));
  }

  // 5. App Icons (iTunesArtwork + AppIcon in bundle)
  const iconBlob = await generateAppIconBlob(config, 512);
  const iconArrayBuffer = await iconBlob.arrayBuffer();
  
  // iTunesArtwork (root, PNG format without extension)
  zip.file('iTunesArtwork', iconArrayBuffer);
  // Root iTunesMetadata.plist
  zip.file('iTunesMetadata.plist', generateItunesMetadata(config));

  // Icons inside bundle
  appFolder.file('AppIcon60x60@2x.png', iconArrayBuffer);
  appFolder.file('AppIcon76x76@2x~ipad.png', iconArrayBuffer);

  // 6. Standalone Web App payload (Capacitor/Cordova style)
  const webBundle = generateStandaloneWebBundle(config);
  const wwwFolder = appFolder.folder('www');
  if (wwwFolder) {
    wwwFolder.file('index.html', webBundle.html);
    wwwFolder.file('style.css', webBundle.css);
    wwwFolder.file('app.js', webBundle.js);
  }

  // Generate the actual IPA blob (which is a ZIP compressed archive)
  const ipaBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 }
  });

  const fileName = `${binaryName}_v${config.version}_build${config.buildNumber}.ipa`;
  return { blob: ipaBlob, fileName };
}

/**
 * Builds the visual file tree representation for the preview/inspector panel.
 */
export function generateIpaTreeStructure(config: AppConfig): IpaFileNode {
  const binaryName = config.appName.replace(/[^a-zA-Z0-9]/g, '') || 'App';
  const infoPlistContent = generateInfoPlist(config);
  const itunesMetadataContent = generateItunesMetadata(config);
  const mobileProvisionContent = generateMobileProvision(config);
  const codeResourcesContent = generateCodeResources(config);
  const webBundle = generateStandaloneWebBundle(config);

  return {
    name: `${binaryName}.ipa`,
    path: '/',
    size: 428000,
    isFolder: true,
    children: [
      {
        name: 'iTunesArtwork',
        path: '/iTunesArtwork',
        size: 52400,
        isFolder: false,
        type: 'image',
        content: '[High-resolution 512x512 PNG app artwork]'
      },
      {
        name: 'iTunesMetadata.plist',
        path: '/iTunesMetadata.plist',
        size: 890,
        isFolder: false,
        type: 'plist',
        content: itunesMetadataContent
      },
      {
        name: 'Payload',
        path: '/Payload',
        size: 374000,
        isFolder: true,
        children: [
          {
            name: `${binaryName}.app`,
            path: `/Payload/${binaryName}.app`,
            size: 374000,
            isFolder: true,
            children: [
              {
                name: 'Info.plist',
                path: `/Payload/${binaryName}.app/Info.plist`,
                size: infoPlistContent.length,
                isFolder: false,
                type: 'plist',
                content: infoPlistContent
              },
              {
                name: binaryName,
                path: `/Payload/${binaryName}.app/${binaryName}`,
                size: 204800,
                isFolder: false,
                type: 'binary',
                content: `Mach-O 64-bit arm64 executable\nIdentifier: ${config.bundleId}\nArchitecture: arm64\nFormat: Mach-O MH_EXECUTE\nLoad commands: LC_SEGMENT_64, LC_LOAD_DYLINKER, LC_MAIN, LC_CODE_SIGNATURE`
              },
              {
                name: 'embedded.mobileprovision',
                path: `/Payload/${binaryName}.app/embedded.mobileprovision`,
                size: mobileProvisionContent.length,
                isFolder: false,
                type: 'plist',
                content: mobileProvisionContent
              },
              {
                name: 'AppIcon60x60@2x.png',
                path: `/Payload/${binaryName}.app/AppIcon60x60@2x.png`,
                size: 18400,
                isFolder: false,
                type: 'image',
                content: '[120x120 Retina iPhone App Icon]'
              },
              {
                name: '_CodeSignature',
                path: `/Payload/${binaryName}.app/_CodeSignature`,
                size: 4200,
                isFolder: true,
                children: [
                  {
                    name: 'CodeResources',
                    path: `/Payload/${binaryName}.app/_CodeSignature/CodeResources`,
                    size: codeResourcesContent.length,
                    isFolder: false,
                    type: 'signature',
                    content: codeResourcesContent
                  }
                ]
              },
              {
                name: 'www',
                path: `/Payload/${binaryName}.app/www`,
                size: 24000,
                isFolder: true,
                children: [
                  {
                    name: 'index.html',
                    path: `/Payload/${binaryName}.app/www/index.html`,
                    size: webBundle.html.length,
                    isFolder: false,
                    type: 'code',
                    content: webBundle.html
                  },
                  {
                    name: 'style.css',
                    path: `/Payload/${binaryName}.app/www/style.css`,
                    size: webBundle.css.length,
                    isFolder: false,
                    type: 'code',
                    content: webBundle.css
                  },
                  {
                    name: 'app.js',
                    path: `/Payload/${binaryName}.app/www/app.js`,
                    size: webBundle.js.length,
                    isFolder: false,
                    type: 'code',
                    content: webBundle.js
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  };
}

/**
 * Unpacks an uploaded .ipa file using JSZip and builds an interactive inspection tree
 */
export async function parseUploadedIpa(file: File): Promise<IpaFileNode> {
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(file);

  const root: IpaFileNode = {
    name: file.name,
    path: '/',
    size: file.size,
    isFolder: true,
    children: []
  };

  const fileMap: { [path: string]: IpaFileNode } = { '/': root };

  const entries = Object.keys(loadedZip.files);
  for (const relativePath of entries) {
    const zipEntry = loadedZip.files[relativePath];
    const cleanPath = '/' + relativePath.replace(/\/$/, '');
    const parts = cleanPath.split('/').filter(Boolean);
    const fileName = parts[parts.length - 1];

    let content: string | undefined;
    let type: IpaFileNode['type'] = 'other';

    if (fileName.endsWith('.plist')) {
      type = 'plist';
      try {
        content = await zipEntry.async('text');
      } catch {
        content = '[Binary Plist file - not plain UTF-8]';
      }
    } else if (fileName.endsWith('.html') || fileName.endsWith('.js') || fileName.endsWith('.css') || fileName.endsWith('.json')) {
      type = 'code';
      try {
        content = await zipEntry.async('text');
      } catch {
        content = '[Content unreadable]';
      }
    } else if (fileName.endsWith('.png') || fileName.endsWith('.jpg') || fileName.includes('Artwork')) {
      type = 'image';
      content = `[Image file - ${zipEntry.dir ? 'Directory' : 'Asset'}]`;
    } else if (cleanPath.includes('_CodeSignature')) {
      type = 'signature';
      try {
        content = await zipEntry.async('text');
      } catch {
        content = '[Code signature data]';
      }
    } else if (!zipEntry.dir) {
      type = 'binary';
      content = `[Binary file / Asset: ${fileName}]`;
    }

    const node: IpaFileNode = {
      name: fileName,
      path: cleanPath,
      size: (zipEntry as unknown as { _data?: { uncompressedSize?: number } })._data?.uncompressedSize || 1024,
      isFolder: zipEntry.dir,
      type,
      content,
      children: zipEntry.dir ? [] : undefined
    };

    fileMap[cleanPath] = node;
  }

  // Connect parents and children
  for (const relativePath of entries) {
    const cleanPath = '/' + relativePath.replace(/\/$/, '');
    const parts = cleanPath.split('/').filter(Boolean);
    if (parts.length === 1) {
      root.children?.push(fileMap[cleanPath]);
    } else {
      const parentPath = '/' + parts.slice(0, -1).join('/');
      const parent = fileMap[parentPath];
      if (parent && parent.children && !parent.children.some(c => c.path === cleanPath)) {
        parent.children.push(fileMap[cleanPath]);
      }
    }
  }

  return root;
}
