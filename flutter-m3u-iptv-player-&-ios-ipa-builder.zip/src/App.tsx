import React, { useState, useEffect, useRef } from 'react';
import Hls from 'hls.js';
import JSZip from 'jszip';
import {
  Play,
  Pause,
  Tv,
  Download,
  Copy,
  Check,
  Search,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  FileCode2,
  Terminal,
  Layers,
  ChevronRight,
  AlertCircle,
  Volume2,
  VolumeX,
  Maximize2,
  Sparkles,
  Smartphone,
  ArrowLeft,
  Info
} from 'lucide-react';

interface ChannelItem {
  id: string;
  name: string;
  url: string;
  logo?: string;
  group?: string;
}

const PRESET_STREAMS = [
  {
    name: 'Big Buck Bunny (Live HLS)',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    logo: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=120&h=120&fit=crop&q=80',
    group: 'Animation & Film'
  },
  {
    name: 'Tears of Steel (720p Multi-bitrate HLS)',
    url: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
    logo: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=120&h=120&fit=crop&q=80',
    group: 'Sci-Fi'
  },
  {
    name: 'Akamai Sintel Stream (HLS)',
    url: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    logo: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=120&h=120&fit=crop&q=80',
    group: 'Cinema'
  },
  {
    name: 'BipBop Basic Test (Apple HLS Sample)',
    url: 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8',
    logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&h=120&fit=crop&q=80',
    group: 'Apple Test'
  }
];

const SAMPLE_M3U_RAW = `#EXTM3U
#EXTINF:-1 tvg-id="bbb" tvg-logo="https://images.unsplash.com/photo-1534447677768-be436bb09401?w=120&h=120&fit=crop&q=80" group-title="Animation",Big Buck Bunny (Live HLS)
https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8

#EXTINF:-1 tvg-id="tos" tvg-logo="https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=120&h=120&fit=crop&q=80" group-title="Sci-Fi",Tears of Steel (720p HLS)
https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8

#EXTINF:-1 tvg-id="sintel" tvg-logo="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=120&h=120&fit=crop&q=80" group-title="Cinema",Akamai Sintel Stream (HLS)
https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8

#EXTINF:-1 tvg-id="apple" tvg-logo="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&h=120&fit=crop&q=80" group-title="Apple Test",BipBop 4x3 (Apple HLS Sample)
https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8
`;

const CODE_PUBSPEC = `name: m3u_player
description: "A cross-platform Flutter M3U IPTV Player with strict iOS compatibility and background audio support."
publish_to: "none"
version: 1.0.0+1

environment:
  sdk: ">=3.3.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  # Core HTTP client for downloading remote M3U/M3U8 playlists
  http: ^1.2.2
  # Official Flutter video player plugin supporting HLS (m3u8), MP4, RTSP
  video_player: ^2.9.2
  # Cupertino & Material styled video player UI wrapper on top of video_player
  chewie: ^1.8.5
  # Keeps the iOS/Android device display awake while playing video streams
  wakelock_plus: ^1.2.8
  # iOS Cupertino-styled icons for Apple native aesthetic
  cupertino_icons: ^1.0.8

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^5.0.0

flutter:
  uses-material-design: true
`;

const CODE_INFO_PLIST = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key>
	<string>$(DEVELOPMENT_LANGUAGE)</string>
	<key>CFBundleDisplayName</key>
	<string>M3U IPTV Player</string>
	<key>CFBundleExecutable</key>
	<string>$(EXECUTABLE_NAME)</string>
	<key>CFBundleIdentifier</key>
	<string>$(PRODUCT_BUNDLE_IDENTIFIER)</string>
	<key>CFBundleInfoDictionaryVersion</key>
	<string>6.0</string>
	<key>CFBundleName</key>
	<string>m3u_player</string>
	<key>CFBundlePackageType</key>
	<string>APPL</string>
	<key>CFBundleShortVersionString</key>
	<string>$(FLUTTER_BUILD_NAME)</string>
	<key>CFBundleSignature</key>
	<string>????</string>
	<key>CFBundleVersion</key>
	<string>$(FLUTTER_BUILD_NUMBER)</string>
	<key>LSRequiresIPhoneOS</key>
	<true/>
	<key>UILaunchStoryboardName</key>
	<string>LaunchScreen</string>
	<key>UIMainStoryboardFile</key>
	<string>Main</string>
	<key>UISupportedInterfaceOrientations</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
		<string>UIInterfaceOrientationLandscapeLeft</string>
		<string>UIInterfaceOrientationLandscapeRight</string>
	</array>
	<key>CADisableMinimumFrameDurationOnPhone</key>
	<true/>
	<key>UIApplicationSupportsIndirectInputEvents</key>
	<true/>

	<!-- ============================================================= -->
	<!-- 1. STRICT iOS APP TRANSPORT SECURITY (ATS)                     -->
	<!-- REQUIRED FOR M3U STREAMS: Allows plain HTTP connections and    -->
	<!-- self-signed IPTV stream servers without TLS 1.3 rejection.     -->
	<!-- ============================================================= -->
	<key>NSAppTransportSecurity</key>
	<dict>
		<key>NSAllowsArbitraryLoads</key>
		<true/>
		<key>NSAllowsArbitraryLoadsForMedia</key>
		<true/>
		<key>NSAllowsArbitraryLoadsInWebContent</key>
		<true/>
	</dict>

	<!-- ============================================================= -->
	<!-- 2. iOS BACKGROUND MODES (Audio & AirPlay)                      -->
	<!-- Ensures live stream audio continues when switching apps or     -->
	<!-- locking the screen.                                            -->
	<!-- ============================================================= -->
	<key>UIBackgroundModes</key>
	<array>
		<string>audio</string>
	</array>

	<key>UIRequiresFullScreen</key>
	<false/>
</dict>
</plist>
`;

const CODE_GITHUB_WORKFLOW = `name: Build iOS Unsigned IPA

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch: # Allows manual 1-click trigger from GitHub Actions tab

jobs:
  build-ipa:
    name: Build Unsigned iOS IPA
    runs-on: macos-latest

    steps:
      # Step 1: Checkout repository
      - name: Checkout Source Code
        uses: actions/checkout@v4

      # Step 2: Set up Flutter SDK
      - name: Setup Flutter
        uses: subosito/flutter-action@v2
        with:
          channel: 'stable'
          cache: true

      # Step 3: Verify Flutter and Xcode tools
      - name: Doctor Check
        run: flutter doctor -v

      # Step 4: Install Flutter dependencies
      - name: Install Dependencies
        run: flutter pub get

      # Step 5: Build iOS App without code signing
      # Produces the native arm64 Runner.app in build/ios/iphoneos
      - name: Build iOS Release Bundle (--no-codesign)
        run: |
          flutter build ios --release --no-codesign

      # Step 6: Assemble the IPA Archive
      # An iOS .ipa file is a ZIP container containing a root 'Payload' folder
      - name: Package Unsigned .ipa Archive
        run: |
          mkdir -p build/ipa/Payload
          cp -r build/ios/iphoneos/Runner.app build/ipa/Payload/
          cd build/ipa
          zip -r -9 ../../m3u-player.ipa Payload
          cd ../..
          echo "Generated m3u-player.ipa ($(ls -lh m3u-player.ipa | awk '{print $5}'))"

      # Step 7: Upload IPA artifact for sideloading (AltStore, Sideloadly, TrollStore)
      - name: Upload IPA Artifact
        uses: actions/upload-artifact@v4
        with:
          name: m3u-player-unsigned-ipa
          path: m3u-player.ipa
          retention-days: 30
`;

const CODE_MAIN_DART = `import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const M3uIptvApp());
}

class M3uIptvApp extends StatelessWidget {
  const M3uIptvApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'M3U IPTV Player',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F0F12),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF0A84FF),
          secondary: Color(0xFF30D158),
          surface: Color(0xFF1C1C1E),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1C1C1E),
          elevation: 0,
          titleTextStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
      home: const PlaylistScreen(),
    );
  }
}

class M3uChannel {
  final String title;
  final String url;
  final String? logoUrl;
  final String? group;

  const M3uChannel({
    required this.title,
    required this.url,
    this.logoUrl,
    this.group,
  });
}

class PlaylistScreen extends StatefulWidget {
  const PlaylistScreen({super.key});
  @override
  State<PlaylistScreen> createState() => _PlaylistScreenState();
}

class _PlaylistScreenState extends State<PlaylistScreen> {
  final TextEditingController _urlController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  List<M3uChannel> _channels = [];
  List<M3uChannel> _filteredChannels = [];
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _urlController.text = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';
    _searchController.addListener(_filterChannels);
  }

  @override
  void dispose() {
    _urlController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  List<M3uChannel> _parseM3u(String content) {
    final List<M3uChannel> channels = [];
    final lines = content.split(RegExp(r'\\r?\\n'));

    String currentTitle = 'Live Stream';
    String? currentLogo;
    String? currentGroup;

    final logoRegex = RegExp(r'tvg-logo="([^"]*)"', caseSensitive: false);
    final groupRegex = RegExp(r'group-title="([^"]*)"', caseSensitive: false);

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;

      if (line.startsWith('#EXTINF:')) {
        final logoMatch = logoRegex.firstMatch(line);
        if (logoMatch != null) currentLogo = logoMatch.group(1);

        final groupMatch = groupRegex.firstMatch(line);
        if (groupMatch != null) currentGroup = groupMatch.group(1);

        final commaIdx = line.lastIndexOf(',');
        if (commaIdx != -1 && commaIdx < line.length - 1) {
          currentTitle = line.substring(commaIdx + 1).trim();
        }
      } else if (!line.startsWith('#')) {
        if (line.startsWith('http://') || line.startsWith('https://')) {
          channels.add(
            M3uChannel(
              title: currentTitle,
              url: line,
              logoUrl: currentLogo,
              group: currentGroup,
            ),
          );
        }
        currentTitle = 'Live Stream';
        currentLogo = null;
        currentGroup = null;
      }
    }
    return channels;
  }

  Future<void> _fetchAndParsePlaylist() async {
    final urlText = _urlController.text.trim();
    if (urlText.isEmpty) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final response = await http.get(Uri.parse(urlText)).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final parsed = _parseM3u(response.body);
        if (parsed.isEmpty) {
          // If single stream link pasted directly
          if (urlText.endsWith('.m3u8') || urlText.endsWith('.mp4')) {
            final single = [M3uChannel(title: 'Live Stream Channel', url: urlText)];
            setState(() {
              _channels = single;
              _filteredChannels = single;
            });
          } else {
            setState(() => _errorMessage = 'No valid stream URLs found.');
          }
        } else {
          setState(() {
            _channels = parsed;
            _filteredChannels = parsed;
          });
        }
      } else {
        setState(() => _errorMessage = 'Server error \${response.statusCode}');
      }
    } catch (e) {
      setState(() => _errorMessage = 'Network error: \$e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _filterChannels() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredChannels = query.isEmpty
          ? _channels
          : _channels.where((c) => c.title.toLowerCase().contains(query)).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('M3U IPTV Player'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _urlController,
                    decoration: const InputDecoration(
                      hintText: 'Enter M3U Playlist URL',
                      filled: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _isLoading ? null : _fetchAndParsePlaylist,
                  child: _isLoading
                      ? const CircularProgressIndicator()
                      : const Text('Parse'),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filteredChannels.length,
              itemBuilder: (context, index) {
                final ch = _filteredChannels[index];
                return ListTile(
                  title: Text(ch.title),
                  subtitle: Text(ch.group ?? 'Stream'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => LivePlayerScreen(channel: ch),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class LivePlayerScreen extends StatefulWidget {
  final M3uChannel channel;
  const LivePlayerScreen({super.key, required this.channel});
  @override
  State<LivePlayerScreen> createState() => _LivePlayerScreenState();
}

class _LivePlayerScreenState extends State<LivePlayerScreen> {
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    try {
      _videoPlayerController = VideoPlayerController.networkUrl(
        Uri.parse(widget.channel.url),
        videoPlayerOptions: VideoPlayerOptions(allowBackgroundPlayback: true),
      );
      await _videoPlayerController!.initialize();
      _chewieController = ChewieController(
        videoPlayerController: _videoPlayerController!,
        autoPlay: true,
        isLive: true,
      );
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => _hasError = true);
    }
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    _videoPlayerController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.channel.title)),
      body: Center(
        child: _hasError
            ? const Text('Stream is offline or unreachable')
            : (_chewieController != null && _chewieController!.videoPlayerController.value.isInitialized)
                ? Chewie(controller: _chewieController!)
                : const CircularProgressIndicator(),
      ),
    );
  }
}
`;

export default function App() {
  const [activeTab, setActiveTab] = useState<'flutter' | 'pubspec' | 'infoplist' | 'actions' | 'sideload'>('flutter');
  const [copiedTab, setCopiedTab] = useState<string | null>(null);
  const [isGeneratingIpa, setIsGeneratingIpa] = useState(false);

  // Simulator state
  const [m3uInputUrl, setM3uInputUrl] = useState('https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8');
  const [channels, setChannels] = useState<ChannelItem[]>(PRESET_STREAMS.map((s, idx) => ({
    id: `ch-${idx}`,
    name: s.name,
    url: s.url,
    logo: s.logo,
    group: s.group
  })));
  const [selectedChannel, setSelectedChannel] = useState<ChannelItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoadingChannels, setIsLoadingChannels] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);

  // Handle stream playback
  useEffect(() => {
    if (!selectedChannel) {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      return;
    }

    setStreamError(null);
    setIsPlaying(false);

    const video = videoRef.current;
    if (!video) return;

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    const streamUrl = selectedChannel.url;

    if (Hls.isSupported() && streamUrl.includes('.m3u8')) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
      });
      hlsRef.current = hls;
      hls.loadSource(streamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().then(() => setIsPlaying(true)).catch(() => {
          // Browser autoplay restriction
        });
      });

      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              setStreamError('Stream network error. Host might be offline or blocked by CORS.');
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              setStreamError('Media decoding error.');
              hls.recoverMediaError();
              break;
            default:
              setStreamError('Stream playback encountered a fatal error.');
              hls.destroy();
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl') || streamUrl.endsWith('.mp4')) {
      // Native Safari / iOS HLS or MP4
      video.src = streamUrl;
      video.play().then(() => setIsPlaying(true)).catch(() => {});
      video.onerror = () => {
        setStreamError('Stream is offline or cannot be decoded.');
      };
    } else {
      video.src = streamUrl;
      video.play().then(() => setIsPlaying(true)).catch(() => {
        setStreamError('Playback format requires HLS support.');
      });
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [selectedChannel]);

  const handleParseM3u = () => {
    setIsLoadingChannels(true);
    setStreamError(null);

    // Simulate parsing or load presets if user pasted sample
    setTimeout(() => {
      const input = m3uInputUrl.trim();
      if (!input) {
        setIsLoadingChannels(false);
        return;
      }

      if (input.includes('x36xhzz') || input.includes('mux.dev') || input.length < 50) {
        setChannels(PRESET_STREAMS.map((s, idx) => ({
          id: `ch-${Date.now()}-${idx}`,
          name: s.name,
          url: s.url,
          logo: s.logo,
          group: s.group
        })));
      } else {
        // Simple client-side M3U text parser
        const lines = input.split('\n');
        const parsed: ChannelItem[] = [];
        let currentTitle = 'Stream Channel';
        let currentLogo: string | undefined;
        let currentGroup: string | undefined;

        for (const rawLine of lines) {
          const line = rawLine.trim();
          if (line.startsWith('#EXTINF:')) {
            const logoMatch = line.match(/tvg-logo="([^"]*)"/i);
            if (logoMatch) currentLogo = logoMatch[1];
            const groupMatch = line.match(/group-title="([^"]*)"/i);
            if (groupMatch) currentGroup = groupMatch[1];

            const commaIdx = line.lastIndexOf(',');
            if (commaIdx !== -1) {
              currentTitle = line.substring(commaIdx + 1).trim();
            }
          } else if (line.startsWith('http://') || line.startsWith('https://')) {
            parsed.push({
              id: `ch-${Date.now()}-${parsed.length}`,
              name: currentTitle,
              url: line,
              logo: currentLogo,
              group: currentGroup
            });
            currentTitle = 'Stream Channel';
            currentLogo = undefined;
            currentGroup = undefined;
          }
        }

        if (parsed.length > 0) {
          setChannels(parsed);
        } else {
          // Single stream URL
          setChannels([{
            id: `ch-${Date.now()}`,
            name: 'Custom Stream',
            url: input,
            group: 'Direct Stream'
          }]);
        }
      }
      setIsLoadingChannels(false);
    }, 400);
  };

  const copyCode = (text: string, tabKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(tabKey);
    setTimeout(() => setCopiedTab(null), 2000);
  };

  const downloadFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadPrototypeIpa = async () => {
    setIsGeneratingIpa(true);
    try {
      const zip = new JSZip();
      const payload = zip.folder('Payload');
      const runnerApp = payload?.folder('Runner.app');

      if (runnerApp) {
        runnerApp.file('Info.plist', CODE_INFO_PLIST);
        runnerApp.file('PkgInfo', 'APPL????');
        
        // Mach-O ARM64 binary header stub (MH_MAGIC_64)
        const machO = new Uint8Array(1024);
        machO[0] = 0xcf; machO[1] = 0xfa; machO[2] = 0xed; machO[3] = 0xfe;
        machO[4] = 0x0c; machO[5] = 0x00; machO[6] = 0x00; machO[7] = 0x01;
        runnerApp.file('Runner', machO);

        // embedded.mobileprovision stub
        runnerApp.file('embedded.mobileprovision', `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>AppIDName</key><string>M3U IPTV Player</string>
  <key>ApplicationIdentifierPrefix</key><array><string>TEAMID</string></array>
  <key>Name</key><string>iOS Team Provisioning Profile: com.example.m3uPlayer</string>
</dict>
</plist>`);
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'm3u-player-unsigned.ipa';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingIpa(false);
    }
  };

  const downloadAllFlutterFiles = async () => {
    const zip = new JSZip();
    zip.file('pubspec.yaml', CODE_PUBSPEC);
    zip.file('lib/main.dart', CODE_MAIN_DART);
    zip.file('ios/Runner/Info.plist', CODE_INFO_PLIST);
    zip.file('.github/workflows/build-ios.yml', CODE_GITHUB_WORKFLOW);

    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'm3u-iptv-flutter-project.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const filteredChannels = channels.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (c.group && c.group.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 font-sans flex flex-col">
      {/* Top Header */}
      <header className="border-b border-neutral-800 bg-neutral-900/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Tv className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  Flutter M3U IPTV Player & iOS IPA Builder
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Ready to Push
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Flutter 3.x • Strict iOS ATS & Background Audio • GitHub Actions CI for Unsigned .ipa
              </p>
            </div>
          </div>

          {/* Header Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={downloadPrototypeIpa}
              disabled={isGeneratingIpa}
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-xs font-semibold text-neutral-200 flex items-center gap-1.5 transition-colors active:scale-95"
              title="Download instant sample .ipa structure"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              {isGeneratingIpa ? 'Packaging IPA...' : 'Get .IPA Sample'}
            </button>
            <button
              onClick={downloadAllFlutterFiles}
              className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white flex items-center gap-1.5 shadow-sm transition-colors active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              Download All Files (.zip)
            </button>
          </div>
        </div>
      </header>

      {/* Main Content: 2-Column Split */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Interactive iPhone Simulator */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="w-full mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                Live iOS Flutter Simulator
              </span>
            </div>
            <span className="text-[11px] text-neutral-500 font-mono">
              iPhone 16 Pro • iOS 18
            </span>
          </div>

          {/* iPhone Chassis */}
          <div className="w-full max-w-[360px] h-[700px] rounded-[48px] bg-neutral-900 border-[10px] border-neutral-800 shadow-2xl relative overflow-hidden flex flex-col select-none ring-1 ring-white/10">
            {/* iOS Dynamic Island & Status Bar */}
            <div className="pt-3 px-6 pb-2 flex items-center justify-between bg-black text-white text-xs z-20 shrink-0">
              <span className="font-semibold text-[11px] tracking-tight">9:41</span>
              <div className="w-24 h-6 rounded-full bg-black border border-neutral-800 flex items-center justify-center text-[10px] text-neutral-400 gap-1.5 shadow-inner">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[9px] font-mono">M3U LIVE</span>
              </div>
              <div className="flex items-center gap-1.5 text-[10px]">
                <span>5G</span>
                <div className="w-4 h-2 rounded-xs border border-white/80 p-0.5 flex">
                  <div className="w-full h-full bg-white rounded-2xs" />
                </div>
              </div>
            </div>

            {/* Screen Content */}
            <div className="flex-1 bg-[#0F0F12] text-white flex flex-col overflow-hidden relative">
              {/* Screen Header */}
              <div className="px-4 py-3 bg-[#1C1C1E] border-b border-neutral-800 flex items-center justify-between shrink-0">
                {selectedChannel ? (
                  <button
                    onClick={() => setSelectedChannel(null)}
                    className="flex items-center gap-1 text-xs text-blue-400 font-medium hover:text-blue-300"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back to Channels
                  </button>
                ) : (
                  <div className="flex items-center gap-2">
                    <Tv className="w-4 h-4 text-blue-400" />
                    <span className="text-sm font-bold">M3U IPTV Player</span>
                  </div>
                )}
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400">
                  {channels.length} Streams
                </span>
              </div>

              {/* View 1: Active Stream Video Player */}
              {selectedChannel ? (
                <div className="flex-1 flex flex-col bg-black">
                  {/* Video Viewport */}
                  <div className="relative aspect-video w-full bg-neutral-900 flex items-center justify-center overflow-hidden">
                    <video
                      ref={videoRef}
                      className="w-full h-full object-contain"
                      playsInline
                      muted={isMuted}
                      onPlay={() => setIsPlaying(true)}
                      onPause={() => setIsPlaying(false)}
                    />

                    {/* Stream Error Overlay */}
                    {streamError && (
                      <div className="absolute inset-0 bg-black/80 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center">
                        <AlertCircle className="w-8 h-8 text-amber-400 mb-2" />
                        <div className="text-xs font-semibold text-white">Stream Error</div>
                        <div className="text-[11px] text-neutral-400 mt-1 max-w-[220px]">{streamError}</div>
                        <button
                          onClick={() => {
                            const cur = selectedChannel;
                            setSelectedChannel(null);
                            setTimeout(() => setSelectedChannel(cur), 100);
                          }}
                          className="mt-3 px-3 py-1 bg-blue-600 rounded-lg text-xs font-medium text-white flex items-center gap-1"
                        >
                          <RefreshCw className="w-3 h-3" /> Retry
                        </button>
                      </div>
                    )}

                    {/* Live Stream Watermark Badge */}
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-red-600/90 text-white text-[9px] font-bold tracking-wider flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                      LIVE
                    </div>

                    {/* Simple overlay controls */}
                    <div className="absolute bottom-2 right-2 flex items-center gap-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded-lg">
                      <button
                        onClick={() => {
                          if (videoRef.current) {
                            if (isPlaying) videoRef.current.pause();
                            else videoRef.current.play();
                          }
                        }}
                        className="text-white hover:text-blue-400"
                      >
                        {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => {
                          setIsMuted(!isMuted);
                          if (videoRef.current) videoRef.current.muted = !isMuted;
                        }}
                        className="text-white hover:text-blue-400"
                      >
                        {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* Channel Details under player */}
                  <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#16161A]">
                    <div>
                      <div className="text-sm font-bold text-white">{selectedChannel.name}</div>
                      <div className="text-xs text-neutral-400 mt-0.5">{selectedChannel.group || 'Live IPTV Channel'}</div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#242429] space-y-1.5 border border-neutral-800">
                      <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Stream URL</div>
                      <div className="text-[11px] font-mono text-blue-400 break-all">{selectedChannel.url}</div>
                    </div>

                    <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-800/40 text-[11px] text-blue-200 leading-relaxed">
                      <strong className="text-blue-300 block mb-1">iOS Info.plist Verification:</strong>
                      Plain HTTP & HLS playback is enabled via <code className="text-blue-400 font-mono">NSAllowsArbitraryLoads</code>. Background Audio is enabled for background stream playback.
                    </div>
                  </div>
                </div>
              ) : (
                /* View 2: Playlist Input & Channel List */
                <div className="flex-1 flex flex-col overflow-hidden">
                  {/* Playlist URL Input Bar */}
                  <div className="p-3 bg-[#16161A] border-b border-neutral-800 space-y-2 shrink-0">
                    <div className="text-[10px] font-bold tracking-wider uppercase text-neutral-400">
                      M3U / M3U8 Playlist URL
                    </div>
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        value={m3uInputUrl}
                        onChange={e => setM3uInputUrl(e.target.value)}
                        placeholder="https://example.com/playlist.m3u"
                        className="flex-1 px-2.5 py-1.5 text-xs rounded-lg bg-[#242429] border border-neutral-700 text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500"
                      />
                      <button
                        onClick={handleParseM3u}
                        disabled={isLoadingChannels}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 rounded-lg text-xs font-semibold text-white flex items-center gap-1 shrink-0"
                      >
                        {isLoadingChannels ? <RefreshCw className="w-3 h-3 animate-spin" /> : 'Parse'}
                      </button>
                    </div>

                    {/* Presets Row */}
                    <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pt-1">
                      <span className="text-[9px] text-neutral-500 shrink-0">Presets:</span>
                      {PRESET_STREAMS.map((p, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            setM3uInputUrl(p.url);
                            setSelectedChannel({
                              id: `preset-${idx}`,
                              name: p.name,
                              url: p.url,
                              logo: p.logo,
                              group: p.group
                            });
                          }}
                          className="px-2 py-0.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-[9px] text-neutral-300 shrink-0 border border-neutral-700 truncate max-w-[110px]"
                        >
                          {p.name.split(' ')[0]}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Search Bar */}
                  <div className="p-2 border-b border-neutral-800/80 bg-[#1C1C1E] shrink-0">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-neutral-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        placeholder="Search channels..."
                        className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#242429] border-none text-white placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  {/* Channel List */}
                  <div className="flex-1 overflow-y-auto divide-y divide-neutral-800/60 no-scrollbar">
                    {filteredChannels.length === 0 ? (
                      <div className="text-center py-12 text-xs text-neutral-500">
                        No channels found.
                      </div>
                    ) : (
                      filteredChannels.map(ch => (
                        <div
                          key={ch.id}
                          onClick={() => setSelectedChannel(ch)}
                          className="p-3 flex items-center justify-between hover:bg-neutral-800/40 cursor-pointer active:bg-neutral-800 transition-colors"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center text-neutral-400 overflow-hidden shrink-0 border border-neutral-700/50">
                              {ch.logo ? (
                                <img src={ch.logo} alt="" className="w-full h-full object-cover" />
                              ) : (
                                <Tv className="w-4 h-4" />
                              )}
                            </div>
                            <div className="min-w-0">
                              <div className="text-xs font-semibold text-white truncate max-w-[190px]">
                                {ch.name}
                              </div>
                              <div className="text-[10px] text-neutral-400">
                                {ch.group || 'Live Stream'}
                              </div>
                            </div>
                          </div>
                          <Play className="w-4 h-4 text-blue-400 shrink-0" />
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* iOS Home Indicator */}
            <div className="h-5 bg-black flex items-center justify-center shrink-0">
              <div className="w-32 h-1 rounded-full bg-white/40" />
            </div>
          </div>
        </div>

        {/* Right Column: Code Deliverables & iOS Config Hub */}
        <div className="lg:col-span-7 flex flex-col">
          {/* Navigation Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-neutral-900 border border-neutral-800 rounded-xl mb-4">
            <button
              onClick={() => setActiveTab('flutter')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                activeTab === 'flutter'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <FileCode2 className="w-3.5 h-3.5" />
              lib/main.dart
            </button>
            <button
              onClick={() => setActiveTab('pubspec')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                activeTab === 'pubspec'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              pubspec.yaml
            </button>
            <button
              onClick={() => setActiveTab('infoplist')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                activeTab === 'infoplist'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              ios/Runner/Info.plist
            </button>
            <button
              onClick={() => setActiveTab('actions')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                activeTab === 'actions'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              build-ios.yml
            </button>
            <button
              onClick={() => setActiveTab('sideload')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                activeTab === 'sideload'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Sideloading Guide
            </button>
          </div>

          {/* Active Tab Panel */}
          <div className="flex-1 bg-neutral-900 border border-neutral-800 rounded-2xl flex flex-col overflow-hidden shadow-xl">
            {/* Header of Active Tab */}
            <div className="px-4 py-3 bg-neutral-900/90 border-b border-neutral-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white">
                  {activeTab === 'flutter' && '1. Complete Flutter App Code (lib/main.dart)'}
                  {activeTab === 'pubspec' && '2. Flutter Dependencies Configuration (pubspec.yaml)'}
                  {activeTab === 'infoplist' && '3. Strict iOS Configuration (ios/Runner/Info.plist)'}
                  {activeTab === 'actions' && '4. GitHub Actions CI Workflow (.github/workflows/build-ios.yml)'}
                  {activeTab === 'sideload' && '5. Sideloading Walkthrough (AltStore, TrollStore, Sideloadly)'}
                </span>
                <p className="text-[11px] text-neutral-400">
                  {activeTab === 'flutter' && 'Self-contained UI, M3U playlist parser, Chewie/VideoPlayer live stream engine.'}
                  {activeTab === 'pubspec' && 'Includes video_player, chewie, http, wakelock_plus, and cupertino_icons.'}
                  {activeTab === 'infoplist' && 'NSAllowsArbitraryLoads (HTTP streams) + UIBackgroundModes (audio/AirPlay).'}
                  {activeTab === 'actions' && 'Runs on macos-latest, compiles --no-codesign, packages Payload into .ipa artifact.'}
                  {activeTab === 'sideload' && 'Direct guide to download artifact and install on your iOS device.'}
                </p>
              </div>

              {activeTab !== 'sideload' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      const code = activeTab === 'flutter' ? CODE_MAIN_DART
                        : activeTab === 'pubspec' ? CODE_PUBSPEC
                        : activeTab === 'infoplist' ? CODE_INFO_PLIST
                        : CODE_GITHUB_WORKFLOW;
                      copyCode(code, activeTab);
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-200 font-medium flex items-center gap-1 transition-colors border border-neutral-700"
                  >
                    {copiedTab === activeTab ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedTab === activeTab ? 'Copied!' : 'Copy Code'}
                  </button>
                  <button
                    onClick={() => {
                      const filename = activeTab === 'flutter' ? 'main.dart'
                        : activeTab === 'pubspec' ? 'pubspec.yaml'
                        : activeTab === 'infoplist' ? 'Info.plist'
                        : 'build-ios.yml';
                      const content = activeTab === 'flutter' ? CODE_MAIN_DART
                        : activeTab === 'pubspec' ? CODE_PUBSPEC
                        : activeTab === 'infoplist' ? CODE_INFO_PLIST
                        : CODE_GITHUB_WORKFLOW;
                      downloadFile(filename, content);
                    }}
                    className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700"
                    title="Download file"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Code Content Area */}
            <div className="flex-1 p-4 overflow-auto font-mono text-xs text-neutral-300 bg-[#0B0B0E] leading-relaxed max-h-[580px]">
              {activeTab === 'flutter' && (
                <pre className="whitespace-pre">{CODE_MAIN_DART}</pre>
              )}
              {activeTab === 'pubspec' && (
                <pre className="whitespace-pre">{CODE_PUBSPEC}</pre>
              )}
              {activeTab === 'infoplist' && (
                <pre className="whitespace-pre">{CODE_INFO_PLIST}</pre>
              )}
              {activeTab === 'actions' && (
                <pre className="whitespace-pre">{CODE_GITHUB_WORKFLOW}</pre>
              )}

              {activeTab === 'sideload' && (
                <div className="font-sans space-y-4 text-xs text-neutral-300">
                  <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-800/40 text-blue-200">
                    <strong className="text-white block text-sm mb-1">How This Pipeline Works:</strong>
                    When you push this repository to GitHub, the workflow in <code className="text-blue-300 font-mono">.github/workflows/build-ios.yml</code> automatically executes on a macOS runner, runs <code className="text-blue-300 font-mono">flutter build ios --release --no-codesign</code>, wraps the <code className="text-blue-300 font-mono">Runner.app</code> into a <code className="text-blue-300 font-mono">Payload</code> folder, and uploads <code className="text-blue-300 font-mono">m3u-player.ipa</code>.
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-sm font-bold text-white">Sideloading Methods for Unsigned .IPA:</h3>

                    {/* Method 1: Sideloadly */}
                    <div className="p-3 rounded-xl bg-neutral-800/60 border border-neutral-700/60">
                      <div className="font-bold text-white text-xs flex items-center justify-between">
                        <span>1. Sideloadly (Windows & macOS - Recommended)</span>
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">Free Apple ID</span>
                      </div>
                      <p className="text-neutral-400 text-[11px] mt-1">
                        Download <code className="text-neutral-200 font-mono">m3u-player.ipa</code> from your GitHub Actions Artifacts. Drag and drop it into Sideloadly, plug in your iPhone, enter your Apple ID, and click <strong>Start</strong>. Sideloadly signs it with your free developer certificate.
                      </p>
                    </div>

                    {/* Method 2: AltStore / SideStore */}
                    <div className="p-3 rounded-xl bg-neutral-800/60 border border-neutral-700/60">
                      <div className="font-bold text-white text-xs flex items-center justify-between">
                        <span>2. AltStore / SideStore</span>
                        <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded">On-Device Refresh</span>
                      </div>
                      <p className="text-neutral-400 text-[11px] mt-1">
                        Save the downloaded <code className="text-neutral-200 font-mono">.ipa</code> to iCloud Drive or the iOS Files app. Open AltStore, tap the <strong>+</strong> button in &quot;My Apps&quot;, and select the .ipa file.
                      </p>
                    </div>

                    {/* Method 3: TrollStore */}
                    <div className="p-3 rounded-xl bg-neutral-800/60 border border-neutral-700/60">
                      <div className="font-bold text-white text-xs flex items-center justify-between">
                        <span>3. TrollStore (iOS 14.0 - 17.0 CoreTrust Bug)</span>
                        <span className="text-[10px] font-mono text-purple-400 bg-purple-500/10 px-1.5 py-0.5 rounded">Permanent - No 7-Day Expiry</span>
                      </div>
                      <p className="text-neutral-400 text-[11px] mt-1">
                        If your device is running compatible iOS versions with TrollStore installed, simply share the .ipa directly to TrollStore. It will install permanently without requiring any certificate or re-signing!
                      </p>
                    </div>

                    {/* Method 4: Push to GitHub Steps */}
                    <div className="p-3 rounded-xl bg-neutral-800/60 border border-neutral-700/60 space-y-2">
                      <div className="font-bold text-white text-xs">
                        How to Push and Trigger the Build on GitHub:
                      </div>
                      <div className="bg-black/80 p-2.5 rounded-lg font-mono text-[11px] text-neutral-300 space-y-1">
                        <div>git init</div>
                        <div>git add .</div>
                        <div>git commit -m &quot;feat: Add Flutter M3U IPTV Player with iOS IPA workflow&quot;</div>
                        <div>git branch -M main</div>
                        <div>git remote add origin https://github.com/&lt;YOUR_USERNAME&gt;/&lt;YOUR_REPO&gt;.git</div>
                        <div>git push -u origin main</div>
                      </div>
                      <p className="text-neutral-400 text-[11px]">
                        Once pushed, navigate to the <strong>Actions</strong> tab in your GitHub repository. The workflow will run and compile the <code className="text-neutral-200 font-mono">m3u-player.ipa</code> artifact ready for download.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
