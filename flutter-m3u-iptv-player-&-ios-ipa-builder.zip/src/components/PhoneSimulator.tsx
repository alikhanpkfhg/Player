import React, { useState, useEffect } from 'react';
import { 
  Wifi, 
  Battery, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Sun, 
  Moon, 
  Smartphone,
  Music,
  Check,
  Radio
} from 'lucide-react';
import { AppConfig } from '../types/ipa';
import { PrototypeApp } from './PrototypeApp';

interface PhoneSimulatorProps {
  config: AppConfig;
  onConfigChange: (updated: Partial<AppConfig>) => void;
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  config,
}) => {
  const [deviceTheme, setDeviceTheme] = useState<'dark' | 'light'>('dark');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [currentTime, setCurrentTime] = useState('9:41');
  const [activeTab, setActiveTab] = useState<'home' | 'tasks' | 'metrics' | 'settings'>('home');
  const [dynamicIslandContent, setDynamicIslandContent] = useState<string | null>(null);
  const [isIslandExpanded, setIsIslandExpanded] = useState(false);
  const [keyReset, setKeyReset] = useState(0);

  // Update status bar clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours % 12 || 12}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  const triggerDynamicIsland = (msg: string) => {
    setDynamicIslandContent(msg);
    setIsIslandExpanded(true);
    setTimeout(() => {
      setIsIslandExpanded(false);
      setTimeout(() => setDynamicIslandContent(null), 300);
    }, 3800);
  };

  const handleResetDevice = () => {
    setKeyReset(prev => prev + 1);
    setActiveTab('home');
    triggerDynamicIsland('App reloaded (Payload memory cleared)');
  };

  return (
    <div className="flex flex-col items-center">
      {/* Device Toolbar / Controls */}
      <div className="w-full max-w-[340px] flex items-center justify-between mb-3 px-2 text-xs text-neutral-500 dark:text-neutral-400">
        <div className="flex items-center gap-1.5 font-medium">
          <Smartphone className="w-3.5 h-3.5 text-neutral-600 dark:text-neutral-300" />
          <span className="text-neutral-700 dark:text-neutral-300">iPhone 16 Pro</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Audio toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-1.5 rounded-lg border transition-colors ${
              soundEnabled 
                ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-900' 
                : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-400 border-neutral-200 dark:border-neutral-700'
            }`}
            title={soundEnabled ? 'Haptic sounds ON' : 'Haptic sounds MUTED'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Theme toggle */}
          <button
            onClick={() => setDeviceTheme(deviceTheme === 'dark' ? 'light' : 'dark')}
            className="p-1.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700 transition-colors"
            title={`Switch device to ${deviceTheme === 'dark' ? 'Light' : 'Dark'} mode`}
          >
            {deviceTheme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          </button>

          {/* Reload app */}
          <button
            onClick={handleResetDevice}
            className="p-1.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700 transition-colors"
            title="Reload Prototype App"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Realistic iPhone 16 Pro Frame */}
      <div className="relative p-2.5 rounded-[52px] bg-gradient-to-b from-neutral-600 via-neutral-400 to-neutral-700 shadow-2xl border border-neutral-400/30">
        {/* Hardware Side Buttons */}
        {/* Silent/Action Button */}
        <div className="absolute -left-3.5 top-24 w-1.5 h-7 bg-neutral-600 rounded-l-sm" />
        {/* Volume Up */}
        <div className="absolute -left-3.5 top-36 w-1.5 h-11 bg-neutral-600 rounded-l-sm" />
        {/* Volume Down */}
        <div className="absolute -left-3.5 top-52 w-1.5 h-11 bg-neutral-600 rounded-l-sm" />
        {/* Power Button */}
        <div className="absolute -right-3.5 top-36 w-1.5 h-16 bg-neutral-600 rounded-r-sm" />

        {/* Screen Bezel */}
        <div className={`w-[320px] h-[640px] rounded-[44px] overflow-hidden flex flex-col justify-between relative shadow-inner border-[3px] border-black transition-colors duration-300 ${
          deviceTheme === 'dark' ? 'dark bg-neutral-950 text-white' : 'bg-white text-neutral-900'
        }`}>
          {/* Top Status Bar & Dynamic Island */}
          <div className="pt-2 px-6 flex items-center justify-between z-30 shrink-0 select-none">
            {/* Clock */}
            <span className="text-[12px] font-semibold tracking-tight w-10 text-neutral-900 dark:text-white">
              {currentTime}
            </span>

            {/* Dynamic Island */}
            <div 
              onClick={() => {
                if (!isIslandExpanded) {
                  triggerDynamicIsland(`${config.appName} Active Session`);
                }
              }}
              className={`bg-black text-white rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer shadow-md overflow-hidden ${
                isIslandExpanded 
                  ? 'px-3 py-1.5 w-52 h-7 gap-2 border border-neutral-800' 
                  : 'w-24 h-6 px-2 gap-1.5'
              }`}
            >
              {isIslandExpanded ? (
                <div className="flex items-center justify-between w-full text-[10px] font-medium animate-fadeIn">
                  <div className="flex items-center gap-1.5 truncate">
                    <Radio className="w-3 h-3 text-blue-400 animate-pulse shrink-0" />
                    <span className="truncate">{dynamicIslandContent || `${config.appName} Running`}</span>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                </div>
              ) : (
                <>
                  <div className="w-2.5 h-2.5 rounded-full bg-neutral-900 border border-neutral-800" />
                  <div className="w-2.5 h-2.5 rounded-full bg-neutral-800" />
                </>
              )}
            </div>

            {/* System Indicators */}
            <div className="flex items-center gap-1.5 w-10 justify-end text-neutral-800 dark:text-neutral-200">
              <span className="text-[10px] font-bold">5G</span>
              <Wifi className="w-3 h-3" />
              <div className="w-5 h-2.5 border border-neutral-800 dark:border-white rounded-xs p-0.5 flex items-center">
                <div className="h-full w-[85%] bg-emerald-500 rounded-xs" />
              </div>
            </div>
          </div>

          {/* Running Prototype App Screen */}
          <div key={keyReset} className="flex-1 overflow-hidden flex flex-col pt-1">
            <PrototypeApp
              config={config}
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              triggerDynamicIsland={triggerDynamicIsland}
              soundEnabled={soundEnabled}
            />
          </div>

          {/* Bottom iOS Home Indicator Bar */}
          <div 
            onClick={() => setActiveTab('home')}
            className="h-5 w-full flex items-center justify-center pb-1.5 shrink-0 cursor-pointer group"
            title="Swipe up / Click for Home"
          >
            <div className="w-32 h-1 bg-neutral-400/80 dark:bg-neutral-600 rounded-full group-hover:bg-blue-500 transition-colors" />
          </div>
        </div>
      </div>
    </div>
  );
};
