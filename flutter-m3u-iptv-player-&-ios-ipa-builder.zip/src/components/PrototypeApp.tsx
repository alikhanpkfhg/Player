import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Plus, 
  Flame, 
  Activity, 
  ShieldCheck, 
  Bell, 
  Camera, 
  MapPin, 
  Sparkles, 
  Check, 
  Sliders, 
  Info,
  Layers,
  Heart,
  Share2,
  Trash2
} from 'lucide-react';
import { AppConfig, PrototypeTask, MetricItem } from '../types/ipa';
import { playIosHaptic } from '../utils/audio';

interface PrototypeAppProps {
  config: AppConfig;
  activeTab: 'home' | 'tasks' | 'metrics' | 'settings';
  setActiveTab: (tab: 'home' | 'tasks' | 'metrics' | 'settings') => void;
  triggerDynamicIsland: (msg: string) => void;
  soundEnabled: boolean;
}

export const PrototypeApp: React.FC<PrototypeAppProps> = ({
  config,
  activeTab,
  setActiveTab,
  triggerDynamicIsland,
  soundEnabled,
}) => {
  const [tasks, setTasks] = useState<PrototypeTask[]>([
    { id: '1', title: 'Verify Info.plist entitlements', category: 'Urgent', completed: true, time: '9:00 AM' },
    { id: '2', title: 'Inspect Mach-O arm64 binary header', category: 'Work', completed: true, time: '10:30 AM' },
    { id: '3', title: 'Test Dynamic Island live activities', category: 'Personal', completed: false, time: '1:15 PM' },
    { id: '4', title: 'Package and sign Payload archive', category: 'Health', completed: false, time: '3:00 PM' },
  ]);

  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [showNotificationAlert, setShowNotificationAlert] = useState(false);
  const [heartRate, setHeartRate] = useState(72);

  const triggerHaptic = (type: 'tap' | 'toggle' | 'success' | 'alert' = 'tap') => {
    if (soundEnabled) {
      playIosHaptic(type);
    }
  };

  const toggleTask = (id: string) => {
    triggerHaptic('toggle');
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const next = !t.completed;
        if (next) triggerDynamicIsland(`Task completed: ${t.title.slice(0, 18)}...`);
        return { ...t, completed: next };
      }
      return t;
    }));
  };

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    triggerHaptic('success');
    const newTask: PrototypeTask = {
      id: Date.now().toString(),
      title: newTaskTitle.trim(),
      category: 'Work',
      completed: false,
      time: 'Just now'
    };
    setTasks(prev => [newTask, ...prev]);
    setNewTaskTitle('');
    triggerDynamicIsland(`Added: ${newTask.title.slice(0, 18)}`);
  };

  const deleteTask = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic('alert');
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const metrics: MetricItem[] = [
    { id: 'm1', label: 'Memory Footprint', value: '24.2', unit: 'MB', change: '-4.1%', positive: true },
    { id: 'm2', label: 'Frame Rate', value: '60', unit: 'FPS', change: 'Rock solid', positive: true },
    { id: 'm3', label: 'Cold Launch', value: '184', unit: 'ms', change: 'Instant', positive: true },
    { id: 'm4', label: 'Bundle Overhead', value: '428', unit: 'KB', change: 'Clean IPA', positive: true },
  ];

  const filteredTasks = tasks.filter(t => {
    if (activeFilter === 'pending') return !t.completed;
    if (activeFilter === 'completed') return t.completed;
    return true;
  });

  const completedCount = tasks.filter(t => t.completed).length;
  const completionPercentage = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  return (
    <div className="h-full w-full flex flex-col justify-between select-none font-sans text-neutral-900 dark:text-neutral-100">
      {/* Scrollable Main Screen Body */}
      <div className="flex-1 overflow-y-auto px-4 pt-1 pb-6 space-y-4 no-scrollbar">
        {/* iOS Native App Navigation Bar */}
        <div className="flex items-center justify-between pt-1">
          <div>
            <div className="text-[11px] uppercase tracking-wider font-semibold text-neutral-400 dark:text-neutral-500">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white flex items-center gap-2">
              {config.appName || 'Prototype App'}
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 font-mono font-medium">
                v{config.version}
              </span>
            </h1>
          </div>
          <div 
            onClick={() => {
              triggerHaptic('tap');
              triggerDynamicIsland(`${config.appName} Live Status: Active`);
            }}
            className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-xs shadow-sm cursor-pointer active:scale-95 transition-transform"
            style={{ backgroundColor: config.themeColor || '#0A84FF' }}
            title="App Icon"
          >
            {config.appName.charAt(0) || 'P'}
          </div>
        </div>

        {/* Tab 1: Home View */}
        {activeTab === 'home' && (
          <div className="space-y-4 animate-fadeIn">
            {/* iOS Widget: Hero Status Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-neutral-900 to-neutral-800 text-white shadow-lg border border-neutral-800 relative overflow-hidden">
              <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 w-28 h-28 rounded-full bg-blue-500/20 blur-xl pointer-events-none" />
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-blue-400 font-medium">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>iOS IPA Prototype</span>
                  </div>
                  <div className="text-xl font-bold mt-1 tracking-tight">
                    {completionPercentage}% Complete
                  </div>
                  <div className="text-xs text-neutral-400 mt-0.5">
                    {completedCount} of {tasks.length} bundle milestones ready
                  </div>
                </div>
                {/* Mini Circular Progress */}
                <div className="w-12 h-12 rounded-full border-4 border-neutral-700 border-t-blue-500 flex items-center justify-center text-xs font-bold text-white">
                  {completionPercentage}%
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-neutral-700/60 rounded-full h-1.5 mt-3 overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-500 ease-out" 
                  style={{ width: `${completionPercentage}%`, backgroundColor: config.themeColor || '#0A84FF' }} 
                />
              </div>

              {/* Quick Action Pills */}
              <div className="mt-3.5 flex items-center gap-2">
                <button
                  onClick={() => {
                    triggerHaptic('tap');
                    triggerDynamicIsland('Testing iOS Audio & Haptics');
                  }}
                  className="flex-1 py-1.5 px-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-[11px] font-medium text-neutral-200 flex items-center justify-center gap-1 transition-colors active:scale-95"
                >
                  <Flame className="w-3 h-3 text-amber-400" />
                  Test Haptic
                </button>
                <button
                  onClick={() => {
                    triggerHaptic('success');
                    setShowNotificationAlert(true);
                  }}
                  className="flex-1 py-1.5 px-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-[11px] font-medium text-neutral-200 flex items-center justify-center gap-1 transition-colors active:scale-95"
                >
                  <Bell className="w-3 h-3 text-blue-400" />
                  iOS Banner
                </button>
              </div>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-2xl bg-neutral-100 dark:bg-neutral-800/80 border border-neutral-200/70 dark:border-neutral-700/50">
                <div className="flex items-center justify-between text-neutral-500 dark:text-neutral-400 text-xs">
                  <span>Architecture</span>
                  <Activity className="w-3.5 h-3.5 text-blue-500" />
                </div>
                <div className="text-base font-bold text-neutral-900 dark:text-white mt-1">
                  ARM64
                </div>
                <div className="text-[10px] text-neutral-400">
                  Target: {config.targetDevice}
                </div>
              </div>

              <div 
                onClick={() => {
                  triggerHaptic('toggle');
                  setHeartRate(prev => prev >= 85 ? 68 : prev + 4);
                }}
                className="p-3 rounded-2xl bg-neutral-100 dark:bg-neutral-800/80 border border-neutral-200/70 dark:border-neutral-700/50 cursor-pointer active:scale-95 transition-transform"
              >
                <div className="flex items-center justify-between text-neutral-500 dark:text-neutral-400 text-xs">
                  <span>HealthKit Sync</span>
                  <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500/20" />
                </div>
                <div className="text-base font-bold text-neutral-900 dark:text-white mt-1 flex items-baseline gap-1">
                  {heartRate} <span className="text-[10px] font-normal text-neutral-400">BPM</span>
                </div>
                <div className="text-[10px] text-neutral-400">
                  {config.permissions.healthKit ? 'Permission granted' : 'Simulated sensor'}
                </div>
              </div>
            </div>

            {/* Priority Tasks Mini List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
                  Current Tasks
                </h3>
                <button
                  onClick={() => setActiveTab('tasks')}
                  className="text-xs text-blue-600 dark:text-blue-400 font-medium hover:underline"
                >
                  View All ({tasks.length})
                </button>
              </div>

              <div className="space-y-1.5">
                {tasks.slice(0, 3).map(task => (
                  <div
                    key={task.id}
                    onClick={() => toggleTask(task.id)}
                    className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                      task.completed 
                        ? 'bg-neutral-50 dark:bg-neutral-900/60 border-neutral-200/60 dark:border-neutral-800/60 opacity-60' 
                        : 'bg-white dark:bg-neutral-800/90 border-neutral-200 dark:border-neutral-700 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <button className="text-blue-500 shrink-0">
                        {task.completed ? (
                          <CheckCircle2 className="w-5 h-5 fill-blue-500 text-white" />
                        ) : (
                          <Circle className="w-5 h-5 text-neutral-400" />
                        )}
                      </button>
                      <span className={`text-xs truncate font-medium ${task.completed ? 'line-through text-neutral-400' : 'text-neutral-800 dark:text-neutral-200'}`}>
                        {task.title}
                      </span>
                    </div>
                    <span className="text-[10px] text-neutral-400 shrink-0 font-mono">
                      {task.time}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Full Tasks View */}
        {activeTab === 'tasks' && (
          <div className="space-y-3.5 animate-fadeIn">
            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-800/80 rounded-xl">
              {(['all', 'pending', 'completed'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => {
                    triggerHaptic('tap');
                    setActiveFilter(f);
                  }}
                  className={`flex-1 py-1 rounded-lg text-xs capitalize font-medium transition-all ${
                    activeFilter === f 
                      ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs' 
                      : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            {/* Add Task Input Form */}
            <form onSubmit={addTask} className="flex gap-1.5">
              <input
                type="text"
                value={newTaskTitle}
                onChange={e => setNewTaskTitle(e.target.value)}
                placeholder="Add new iOS prototype task..."
                className="flex-1 px-3 py-2 text-xs rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center transition-colors active:scale-95"
              >
                <Plus className="w-4 h-4" />
              </button>
            </form>

            {/* Task Items List */}
            <div className="space-y-1.5">
              {filteredTasks.length === 0 ? (
                <div className="text-center py-8 text-neutral-400 text-xs">
                  No tasks matching &quot;{activeFilter}&quot;
                </div>
              ) : (
                filteredTasks.map(task => (
                  <div
                    key={task.id}
                    onClick={() => toggleTask(task.id)}
                    className={`group flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                      task.completed 
                        ? 'bg-neutral-50 dark:bg-neutral-900/40 border-neutral-200/60 dark:border-neutral-800/60 opacity-60' 
                        : 'bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <button className="text-blue-500 shrink-0">
                        {task.completed ? (
                          <CheckCircle2 className="w-5 h-5 fill-blue-500 text-white" />
                        ) : (
                          <Circle className="w-5 h-5 text-neutral-400" />
                        )}
                      </button>
                      <div className="min-w-0 flex-1">
                        <div className={`text-xs font-medium truncate ${task.completed ? 'line-through text-neutral-400' : 'text-neutral-800 dark:text-neutral-200'}`}>
                          {task.title}
                        </div>
                        <div className="text-[10px] text-neutral-400">
                          {task.category} • {task.time}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={(e) => deleteTask(task.id, e)}
                      className="opacity-0 group-hover:opacity-100 p-1 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/40 text-neutral-400 hover:text-red-500 transition-opacity"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Metrics / iOS Diagnostic View */}
        {activeTab === 'metrics' && (
          <div className="space-y-3.5 animate-fadeIn">
            <div className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
              Runtime diagnostics simulated for iOS arm64 environment:
            </div>

            <div className="grid grid-cols-2 gap-2">
              {metrics.map(m => (
                <div key={m.id} className="p-3 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs">
                  <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                    {m.label}
                  </div>
                  <div className="text-lg font-bold text-neutral-900 dark:text-white mt-1 flex items-baseline gap-1">
                    {m.value}
                    <span className="text-xs font-normal text-neutral-400">{m.unit}</span>
                  </div>
                  <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium mt-0.5">
                    {m.change}
                  </div>
                </div>
              ))}
            </div>

            {/* Permissions Audit Checklist */}
            <div className="p-3.5 rounded-2xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 space-y-2">
              <div className="text-xs font-bold text-neutral-900 dark:text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>Info.plist Permissions Declared</span>
              </div>
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-neutral-600 dark:text-neutral-300">
                  <span className="flex items-center gap-1.5"><Camera className="w-3.5 h-3.5" /> Camera</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${config.permissions.camera ? 'bg-emerald-500/10 text-emerald-500' : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-400'}`}>
                    {config.permissions.camera ? 'NSCameraUsage' : 'None'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-neutral-600 dark:text-neutral-300">
                  <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> Location</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${config.permissions.location ? 'bg-emerald-500/10 text-emerald-500' : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-400'}`}>
                    {config.permissions.location ? 'NSLocationWhenInUse' : 'None'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-neutral-600 dark:text-neutral-300">
                  <span className="flex items-center gap-1.5"><Heart className="w-3.5 h-3.5" /> HealthKit</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${config.permissions.healthKit ? 'bg-emerald-500/10 text-emerald-500' : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-400'}`}>
                    {config.permissions.healthKit ? 'NSHealthShare' : 'None'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-neutral-600 dark:text-neutral-300">
                  <span className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5" /> Face ID</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${config.permissions.faceId ? 'bg-emerald-500/10 text-emerald-500' : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-400'}`}>
                    {config.permissions.faceId ? 'NSFaceIDUsage' : 'None'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Settings View */}
        {activeTab === 'settings' && (
          <div className="space-y-3.5 animate-fadeIn">
            <div className="p-3 rounded-2xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 space-y-2.5">
              <div className="text-xs font-bold text-neutral-900 dark:text-white">
                Bundle Identity
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-700/50">
                  <span className="text-neutral-400">Bundle Identifier</span>
                  <span className="font-mono text-neutral-800 dark:text-neutral-200 truncate max-w-[180px]">
                    {config.bundleId}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-700/50">
                  <span className="text-neutral-400">Version / Build</span>
                  <span className="font-mono text-neutral-800 dark:text-neutral-200">
                    {config.version} ({config.buildNumber})
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-700/50">
                  <span className="text-neutral-400">Min iOS Target</span>
                  <span className="text-neutral-800 dark:text-neutral-200">iOS {config.minIosVersion}+</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-neutral-400">Architecture</span>
                  <span className="font-mono text-neutral-800 dark:text-neutral-200">arm64 (Apple Silicon)</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                triggerHaptic('success');
                triggerDynamicIsland('Testing iOS AirDrop / Share Sheet');
              }}
              className="w-full py-2.5 px-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 border border-neutral-200 dark:border-neutral-700 text-xs font-semibold text-neutral-800 dark:text-neutral-200 flex items-center justify-center gap-1.5 transition-colors active:scale-98"
            >
              <Share2 className="w-3.5 h-3.5" />
              Simulate iOS Share Sheet
            </button>
          </div>
        )}
      </div>

      {/* Floating Banner Notification Simulation */}
      {showNotificationAlert && (
        <div 
          onClick={() => setShowNotificationAlert(false)}
          className="mx-3 mb-2 p-3 rounded-2xl bg-neutral-900/95 backdrop-blur-md text-white border border-neutral-700 shadow-xl flex items-start gap-3 cursor-pointer animate-slideDown"
        >
          <div className="w-7 h-7 rounded-lg bg-blue-500 flex items-center justify-center shrink-0">
            <Bell className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between text-[10px] text-neutral-400">
              <span className="font-semibold text-neutral-300">{config.appName}</span>
              <span>now</span>
            </div>
            <div className="text-xs font-semibold text-white mt-0.5">Prototype IPA Ready</div>
            <div className="text-[11px] text-neutral-300 truncate">Tap to test push notification handling</div>
          </div>
        </div>
      )}

      {/* iOS Cupertino Tab Bar */}
      <div className="h-[64px] bg-neutral-100/90 dark:bg-neutral-900/95 backdrop-blur-md border-t border-neutral-200/80 dark:border-neutral-800 px-6 flex items-center justify-around shrink-0">
        <button
          onClick={() => {
            triggerHaptic('tap');
            setActiveTab('home');
          }}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeTab === 'home' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span className="text-[10px]">Today</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic('tap');
            setActiveTab('tasks');
          }}
          className={`flex flex-col items-center gap-1 transition-colors relative ${
            activeTab === 'tasks' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px]">Tasks</span>
          {tasks.filter(t => !t.completed).length > 0 && (
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-blue-500" />
          )}
        </button>

        <button
          onClick={() => {
            triggerHaptic('tap');
            setActiveTab('metrics');
          }}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeTab === 'metrics' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300'
          }`}
        >
          <Activity className="w-5 h-5" />
          <span className="text-[10px]">Metrics</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic('tap');
            setActiveTab('settings');
          }}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeTab === 'settings' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300'
          }`}
        >
          <Sliders className="w-5 h-5" />
          <span className="text-[10px]">Settings</span>
        </button>
      </div>
    </div>
  );
};
