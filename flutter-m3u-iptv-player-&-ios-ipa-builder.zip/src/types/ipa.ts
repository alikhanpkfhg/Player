export interface AppConfig {
  appName: string;
  bundleId: string;
  version: string;
  buildNumber: string;
  minIosVersion: string;
  targetDevice: 'iPhone' | 'iPad' | 'Universal';
  category: string;
  themeColor: string;
  permissions: {
    camera: boolean;
    location: boolean;
    notifications: boolean;
    photoLibrary: boolean;
    faceId: boolean;
    healthKit: boolean;
  };
}

export interface IpaFileNode {
  name: string;
  path: string;
  size: number;
  isFolder: boolean;
  type?: 'plist' | 'binary' | 'image' | 'code' | 'signature' | 'other';
  children?: IpaFileNode[];
  content?: string;
  rawUrl?: string;
}

export interface PrototypeTask {
  id: string;
  title: string;
  category: 'Work' | 'Personal' | 'Health' | 'Urgent';
  completed: boolean;
  time: string;
}

export interface MetricItem {
  id: string;
  label: string;
  value: string;
  unit: string;
  change: string;
  positive: boolean;
}
