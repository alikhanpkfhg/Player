import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Set preferred orientations for media playback
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);

  runApp(const M3uIptvApp());
}

/// Root Application Widget configured with dark/light themes
class M3uIptvApp extends StatelessWidget {
  const M3uIptvApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'M3U IPTV Player',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark, // IPTV looks best in dark mode
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F0F12),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF0A84FF), // iOS System Blue
          secondary: Color(0xFF30D158), // iOS System Green
          surface: Color(0xFF1C1C1E),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1C1C1E),
          elevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        cardColor: const Color(0xFF1C1C1E),
      ),
      home: const PlaylistScreen(),
    );
  }
}

/// Data model representing an individual parsed IPTV channel
class M3uChannel {
  final String title;
  final String url;
  final String? logoUrl;
  final String? group;

  const M3uChannel({
    required this.title,
    required this.url,
    this.logoUrl,
    this.group,
  });
}

/// Primary Screen: URL Input, M3U Parser, and Channel List
class PlaylistScreen extends StatefulWidget {
  const PlaylistScreen({super.key});

  @override
  State<PlaylistScreen> createState() => _PlaylistScreenState();
}

class _PlaylistScreenState extends State<PlaylistScreen> {
  final TextEditingController _urlController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  List<M3uChannel> _channels = [];
  List<M3uChannel> _filteredChannels = [];
  bool _isLoading = false;
  String? _errorMessage;

  // Preset sample IPTV streams for instant testing
  static const String sampleHlsPlaylist =
      'https://iptv-org.github.io/iptv/languages/eng.m3u';

  @override
  void initState() {
    super.initState();
    // Pre-populate with a reliable public English IPTV playlist
    _urlController.text = sampleHlsPlaylist;
    _searchController.addListener(_filterChannels);
  }

  @override
  void dispose() {
    _urlController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  /// Parses M3U/M3U8 playlist format extracting #EXTINF attributes and stream URLs
  List<M3uChannel> _parseM3u(String content) {
    final List<M3uChannel> channels = [];
    final lines = content.split(RegExp(r'\r?\n'));

    String currentTitle = 'Live Stream';
    String? currentLogo;
    String? currentGroup;

    final logoRegex = RegExp(r'tvg-logo="([^"]*)"', caseSensitive: false);
    final groupRegex = RegExp(r'group-title="([^"]*)"', caseSensitive: false);

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;

      if (line.startsWith('#EXTINF:')) {
        // Extract Logo
        final logoMatch = logoRegex.firstMatch(line);
        if (logoMatch != null) {
          currentLogo = logoMatch.group(1);
        }

        // Extract Group/Category
        final groupMatch = groupRegex.firstMatch(line);
        if (groupMatch != null) {
          currentGroup = groupMatch.group(1);
        }

        // Extract Channel Title (everything after the last comma)
        final commaIdx = line.lastIndexOf(',');
        if (commaIdx != -1 && commaIdx < line.length - 1) {
          currentTitle = line.substring(commaIdx + 1).trim();
        } else {
          currentTitle = 'Channel ${channels.length + 1}';
        }
      } else if (!line.startsWith('#')) {
        // Line is a stream URL
        if (line.startsWith('http://') || line.startsWith('https://')) {
          channels.add(
            M3uChannel(
              title: currentTitle,
              url: line,
              logoUrl: (currentLogo != null && currentLogo.isNotEmpty)
                  ? currentLogo
                  : null,
              group: currentGroup,
            ),
          );
        }
        // Reset metadata for next entry
        currentTitle = 'Live Stream';
        currentLogo = null;
        currentGroup = null;
      }
    }

    return channels;
  }

  /// Fetches playlist over HTTP(S) and triggers parsing
  Future<void> _fetchAndParsePlaylist() async {
    final urlText = _urlController.text.trim();
    if (urlText.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter a valid M3U playlist URL.';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final uri = Uri.parse(urlText);
      final response = await http
          .get(uri)
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final parsed = _parseM3u(response.body);
        if (parsed.isEmpty) {
          setState(() {
            _errorMessage =
                'No playable stream links found in playlist. Ensure it contains #EXTINF or stream URLs.';
          });
        } else {
          setState(() {
            _channels = parsed;
            _filteredChannels = parsed;
          });
        }
      } else {
        setState(() {
          _errorMessage =
              'Server responded with HTTP ${response.statusCode}: Failed to load playlist.';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage =
            'Network error: $e\n(Check URL or ensure HTTP plain traffic is permitted in Info.plist)';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _filterChannels() {
    final query = _searchController.text.toLowerCase();
    if (query.isEmpty) {
      setState(() {
        _filteredChannels = _channels;
      });
    } else {
      setState(() {
        _filteredChannels = _channels.where((c) {
          final matchTitle = c.title.toLowerCase().contains(query);
          final matchGroup = c.group?.toLowerCase().contains(query) ?? false;
          return matchTitle || matchGroup;
        }).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(CupertinoIcons.tv, color: Color(0xFF0A84FF), size: 24),
            SizedBox(width: 8),
            Text('M3U IPTV Player'),
          ],
        ),
        actions: [
          if (_channels.isNotEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 16.0),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A84FF).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${_channels.length} Streams',
                    style: const TextStyle(
                      color: Color(0xFF0A84FF),
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Top Config Card (URL input & Load button)
          Container(
            padding: const EdgeInsets.all(16.0),
            color: const Color(0xFF16161A),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'PLAYLIST SOURCE URL',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                    color: Colors.white54,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _urlController,
                        style: const TextStyle(fontSize: 13, color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'https://example.com/playlist.m3u',
                          hintStyle: const TextStyle(color: Colors.white30),
                          filled: true,
                          fillColor: const Color(0xFF242429),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 12,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                          prefixIcon: const Icon(
                            CupertinoIcons.link,
                            color: Colors.white54,
                            size: 18,
                          ),
                          suffixIcon: _urlController.text.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(
                                    CupertinoIcons.clear_circled_solid,
                                    size: 18,
                                    color: Colors.white38,
                                  ),
                                  onPressed: () {
                                    _urlController.clear();
                                    setState(() {});
                                  },
                                )
                              : null,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: _isLoading ? null : _fetchAndParsePlaylist,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0A84FF),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 14,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text(
                              'Load',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                    ),
                  ],
                ),
                // Error message banner
                if (_errorMessage != null) ...[
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.redAccent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.parseBorder(
                        Border.all(color: Colors.redAccent.withOpacity(0.3)),
                      ),
                    ),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                    ),
                  ),
                ],
              ],
            ),
          ),

          // Search Box if channels loaded
          if (_channels.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
              child: TextField(
                controller: _searchController,
                style: const TextStyle(fontSize: 13, color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Search channel name or category...',
                  hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                  filled: true,
                  fillColor: const Color(0xFF1C1C1E),
                  prefixIcon: const Icon(
                    CupertinoIcons.search,
                    color: Colors.white38,
                    size: 18,
                  ),
                  contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),

          // Channel List or Empty State
          Expanded(
            child: _channels.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            CupertinoIcons.play_rectangle,
                            size: 64,
                            color: Colors.white.withOpacity(0.2),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'No Playlist Loaded',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white70,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Paste an M3U / M3U8 link above and tap "Load" to parse IPTV live channels.',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 13, color: Colors.white38),
                          ),
                          const SizedBox(height: 16),
                          OutlinedButton.icon(
                            onPressed: () {
                              _urlController.text = sampleHlsPlaylist;
                              _fetchAndParsePlaylist();
                            },
                            icon: const Icon(CupertinoIcons.arrow_down_circle, size: 16),
                            label: const Text('Load Public Test Playlist'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF0A84FF),
                              side: const BorderSide(color: Color(0xFF0A84FF)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                : ListView.separated(
                    itemCount: _filteredChannels.length,
                    separatorBuilder: (context, index) => const Divider(
                      height: 1,
                      color: Color(0xFF242429),
                    ),
                    itemBuilder: (context, index) {
                      final channel = _filteredChannels[index];
                      return ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 4,
                        ),
                        leading: Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: const Color(0xFF242429),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: channel.logoUrl != null
                              ? Image.network(
                                  channel.logoUrl!,
                                  fit: BoxFit.contain,
                                  errorBuilder: (_, __, ___) => const Icon(
                                    CupertinoIcons.tv,
                                    color: Colors.white38,
                                    size: 20,
                                  ),
                                )
                              : const Icon(
                                  CupertinoIcons.tv,
                                  color: Colors.white38,
                                  size: 20,
                                ),
                        ),
                        title: Text(
                          channel.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                        subtitle: Text(
                          channel.group ?? 'General',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.white54,
                          ),
                        ),
                        trailing: const Icon(
                          CupertinoIcons.play_circle_fill,
                          color: Color(0xFF0A84FF),
                          size: 28,
                        ),
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) =>
                                  LivePlayerScreen(channel: channel),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

/// Dedicated Live Stream Player Screen using VideoPlayer and Chewie
class LivePlayerScreen extends StatefulWidget {
  final M3uChannel channel;

  const LivePlayerScreen({super.key, required this.channel});

  @override
  State<LivePlayerScreen> createState() => _LivePlayerScreenState();
}

class _LivePlayerScreenState extends State<LivePlayerScreen> {
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  bool _hasError = false;
  String? _errorDetails;

  @override
  void initState() {
    super.initState();
    // Keep device screen awake during video playback
    WakelockPlus.enable();
    _initializePlayer();
  }

  Future<void> _initializePlayer() async {
    setState(() {
      _hasError = false;
      _errorDetails = null;
    });

    try {
      final uri = Uri.parse(widget.channel.url);
      _videoPlayerController = VideoPlayerController.networkUrl(
        uri,
        videoPlayerOptions: VideoPlayerOptions(
          mixWithOthers: false, // Prevents mixing unless background audio desired
          allowBackgroundPlayback: true, // Crucial for iOS background audio
        ),
      );

      // Listen for runtime streaming errors (e.g. offline source, ATS blockage)
      _videoPlayerController!.addListener(() {
        if (_videoPlayerController!.value.hasError) {
          if (mounted) {
            setState(() {
              _hasError = true;
              _errorDetails = _videoPlayerController!.value.errorDescription;
            });
          }
        }
      });

      await _videoPlayerController!.initialize();

      // Configure Chewie player interface
      _chewieController = ChewieController(
        videoPlayerController: _videoPlayerController!,
        autoPlay: true,
        isLive: true,
        looping: true,
        allowFullScreen: true,
        allowMuting: true,
        showControls: true,
        materialProgressColors: ChewieProgressColors(
          playedColor: const Color(0xFF0A84FF),
          handleColor: const Color(0xFF0A84FF),
          backgroundColor: Colors.white24,
          bufferedColor: Colors.white38,
        ),
        cupertinoProgressColors: ChewieProgressColors(
          playedColor: const Color(0xFF0A84FF),
          handleColor: const Color(0xFF0A84FF),
          backgroundColor: Colors.white24,
          bufferedColor: Colors.white38,
        ),
        errorBuilder: (context, errorMessage) {
          return _buildErrorState(errorMessage);
        },
      );

      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _hasError = true;
          _errorDetails = e.toString();
        });
      }
    }
  }

  Widget _buildErrorState(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              CupertinoIcons.exclamationmark_triangle_fill,
              color: Colors.amber,
              size: 48,
            ),
            const SizedBox(height: 12),
            const Text(
              'Stream Offline or Unreachable',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: Colors.white54),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                _videoPlayerController?.dispose();
                _chewieController?.dispose();
                _initializePlayer();
              },
              icon: const Icon(CupertinoIcons.refresh, size: 16),
              label: const Text('Retry Stream'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0A84FF),
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    _videoPlayerController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.channel.title,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: Colors.redAccent,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 4),
                const Text(
                  'LIVE STREAM',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                    color: Colors.redAccent,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Video Player Area
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Container(
                color: Colors.black,
                child: _hasError
                    ? _buildErrorState(_errorDetails ?? 'Playback failed')
                    : (_chewieController != null &&
                            _chewieController!
                                .videoPlayerController.value.isInitialized)
                        ? Chewie(controller: _chewieController!)
                        : const Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CircularProgressIndicator(
                                  color: Color(0xFF0A84FF),
                                ),
                                SizedBox(height: 12),
                                Text(
                                  'Connecting to stream...',
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
              ),
            ),

            // Stream Info & Metadata Details
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(20),
                color: const Color(0xFF16161A),
                child: ListView(
                  children: [
                    Text(
                      widget.channel.title,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Category: ${widget.channel.group ?? "General"}',
                      style: const TextStyle(fontSize: 13, color: Colors.white54),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'STREAM DETAILS',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.8,
                        color: Colors.white38,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF242429),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Raw Stream URL:',
                            style: TextStyle(fontSize: 11, color: Colors.white54),
                          ),
                          const SizedBox(height: 4),
                          SelectableText(
                            widget.channel.url,
                            style: const TextStyle(
                              fontSize: 12,
                              fontFamily: 'monospace',
                              color: Color(0xFF0A84FF),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    // iOS Background Audio & ATS compliance note
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0A84FF).withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: const Color(0xFF0A84FF).withOpacity(0.2),
                        ),
                      ),
                      child: const Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            CupertinoIcons.info_circle,
                            color: Color(0xFF0A84FF),
                            size: 20,
                          ),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'iOS ATS (App Transport Security) is enabled for arbitrary HTTP loads. Background audio mode is enabled in Info.plist.',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.white70,
                                height: 1.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
